//
//  MonthCell.swift
//  AACalendar
//
//  Created by Aravindakumar Arunachalam on 13/10/17.
//  Copyright © 2017 ClickApps. All rights reserved.
//

import UIKit
protocol MonthCellDelegate {
    func dateSelected(date: String)
}
class MonthCell: UITableViewCell {

    @IBOutlet weak var scrollContentView: UIView!
    @IBOutlet weak var lblMonthName: UILabel!

    var weekDayNamesArray:[String] = Array()
    var currentMonth : Int!
    var currentYear : Int!
    var firstDateSelected: String!
    var secondDateSelected: String!
    var isShowPreviousNextMonthDays:Bool = false

    var todayDateBackGroundColor:UIColor?
    var normalDateColor: UIColor?
    var selectedDateColor: UIColor?
    var highlightedDateColor: UIColor?
    var highlightedDateBackgroundColor: UIColor?
    var disableDateColor: UIColor?
    
    @IBOutlet var hgtConstraint: NSLayoutConstraint!
    
    var delegate : MonthCellDelegate!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        weekDayNamesArray = returnWeekDayArray()

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func createCalendar(withMonth month:Int, andYear year: Int)  {
        
        currentMonth = month
        currentYear = year
        let date = returnDateFormatter().date(from:String(format: "1/%d/%d",month, year))//"1/\\\(month)/\\\(year)"
        let numberOfDays = getNumberOfDays(inMonth: month, withDate: date!)
        let  weekDay = getFirstWeekDay(forDate: date!)
        createMonthWith(numberofDays: numberOfDays, andStartingWeekDay: weekDay)
        let dateStr = returnMonthFormatter().string(from: date!)
        let arrayComp = dateStr.components(separatedBy: "/")
        if arrayComp.count == 3 {
            lblMonthName.text = String(format: "%@ %@", arrayComp[1].uppercased(),arrayComp[2])
        }
        

    }
    
    func returnDateFormatter() -> DateFormatter {
        
        let formatter = DateFormatter.init()
        formatter.dateFormat = "dd/MM/yyyy"
        return formatter
    }
    
    func returnMonthFormatter() -> DateFormatter {
        
        let formatter = DateFormatter.init()
        formatter.dateFormat = "dd/MMMM/yyyy"
        return formatter
    }
    
    func returnWeekDayArray() -> Array<String> {
        
        let formatter = DateFormatter.init()
        return formatter.shortWeekdaySymbols
    }

    
    
    func getNumberOfDays(inMonth month:Int, withDate date:Date) -> Int {
        
        let cal = Calendar.current
        var dateComponents = DateComponents.init()
        dateComponents.month = month
        let range = cal.range(of: .day, in: .month, for: date)
        return (range?.count)!
    }
    
    func getFirstWeekDay(forDate date:Date) -> Int {
        let cal = Calendar.current
        let dateComponents = cal.dateComponents([.weekday], from: date)
        return dateComponents.weekday!
    }
    
    
    func createMonthWith(numberofDays days:Int, andStartingWeekDay weekday:Int )  {
        
       
        
        for vw in scrollContentView.subviews {
            if vw.tag != 300 {
               vw.removeFromSuperview()
            }
        }
        var xPos = 10.0
        var yPos = 30.0
        var startIndex = weekday
        
        let width = (contentView.frame.size.width - 20.0) / 7
        let height = width
        
        for weekDaynames in weekDayNamesArray {
            
            let weekDayLable = UILabel.init(frame: CGRect(x: xPos, y: yPos, width: Double(width), height: Double(height)))
            weekDayLable.text = weekDaynames
            weekDayLable.textAlignment = .center
            xPos=xPos+Double(width);
            
        }
        
        xPos = 10.0

        for i in 1...7 {
            
            if i == weekday {
                break
            }
            xPos = xPos + Double(width)
        }
        
        
        for date in 1...days {
         
            let button = UIButton(type: .custom)
            button.addTarget(self, action: #selector( dateSelected(_ :)), for: .touchUpInside)
            button.tag = date
            let dateLable = UILabel.init(frame: CGRect(x: xPos, y: yPos, width: Double(width), height: Double(height)))
            dateLable.text = String(describing: date)
            dateLable.textAlignment = .center
            dateLable.tag = date
            let date = returnDateFormatter().date(from:String(format: "%d/%d/%d",date, currentMonth, currentYear))
            let currentDate = returnDateFormatter().date(from: returnDateFormatter().string(from: Date()))
            button.frame = dateLable.frame
            button.center = dateLable.center
            if date?.compare(currentDate!) == .orderedSame {
                dateLable.backgroundColor = UIColor.purple
                dateLable.textColor = UIColor.white
                dateLable.layoutIfNeeded()
                dateLable.clipsToBounds = true
                dateLable.layer.cornerRadius = dateLable.frame.size.width / 2;
            }
            if firstDateSelected != nil {
                if let startDate = returnDateFormatter().date(from:firstDateSelected) {
                    if date?.compare(startDate) == .orderedSame{
                         dateLable.backgroundColor = UIColor.blue
                        dateLable.textColor = UIColor.white
                        dateLable.layoutIfNeeded()
                        dateLable.clipsToBounds = true
                        dateLable.layer.cornerRadius = dateLable.frame.size.width / 2;
                    }
                }
            }
            
            if secondDateSelected != nil {
                if let startDate = returnDateFormatter().date(from:firstDateSelected) {
                    if let endDate = returnDateFormatter().date(from:secondDateSelected) {
                if date?.compare(endDate) == .orderedSame{
                    dateLable.backgroundColor = UIColor.blue
                    dateLable.textColor = UIColor.white
                    dateLable.layoutIfNeeded()
                    dateLable.clipsToBounds = true
                    dateLable.layer.cornerRadius = dateLable.frame.size.width / 2;
                }
                
                if date?.compare(endDate) == .orderedAscending &&  date?.compare(startDate) == .orderedDescending{
                    
                  
                    dateLable.textColor = UIColor.blue
                    dateLable.layoutIfNeeded()
                    dateLable.clipsToBounds = true


                }
                    }
                }
            }

          

           
            scrollContentView.addSubview(dateLable)
             scrollContentView.addSubview(button)
            startIndex = startIndex + 1
            xPos=xPos+Double(width);
            
            if startIndex == 8 {
                xPos = 10.0
                yPos = yPos+Double(height);
                startIndex = 1;
            }
        }
    }

    func dateSelected(_ sender:AnyObject) {
        if delegate != nil {
           
            delegate.dateSelected(date: String(format: "%d/%d/%d",sender.tag, currentMonth, currentYear))
        }
    }
    
}
