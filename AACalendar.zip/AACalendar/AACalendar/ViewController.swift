//
//  ViewController.swift
//  AACalendar
//
//  Created by Aravindakumar Arunachalam on 13/10/17.
//  Copyright © 2017 ClickApps. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MonthCellDelegate {

    @IBOutlet weak var tblCalendar: UITableView!
    @IBOutlet var DaysLbl: UILabel!
    private var month = 1
    private var year = 2017
    private var yearStarted = 2017
    private var startDate: String!
    private var endDate: String!
    var StartDate = String()
    var EndDate = String()
    var startNDEnd = String()
    var startNDEndArr = NSMutableArray()
    var weekDayNamesArray:[String] = Array()

    @IBOutlet var HightView: UIView!
    @IBOutlet var SaveBT: UIButton!
    
var dataArr = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        startDate = ""
        endDate = ""
        // Do any additional setup after loading the view, typically from a nib.
        tblCalendar.register(UINib(nibName: "MonthCell", bundle: nil), forCellReuseIdentifier: "calendar_identifier")
        tblCalendar.dataSource = self
        tblCalendar.delegate = self
        tblCalendar.estimatedRowHeight = 300
        SaveBT.layer.cornerRadius = 5
        SaveBT.layer.borderWidth = 1
        SaveBT.layer.borderColor = UIColor.orange.cgColor
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 200
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
    
        let cell = tableView.dequeueReusableCell(withIdentifier:"calendar_identifier") as! MonthCell
        cell.delegate = self
        var cellFrame = cell.contentView.frame
        cellFrame.size.width = self.view.frame.size.width
        cell.contentView.frame = cellFrame
        
         cell.firstDateSelected = ""
         cell.secondDateSelected = ""
        if startDate.characters.count != 0 {
            cell.firstDateSelected = startDate
            StartDate = startDate!
            
        }
        if endDate.characters.count != 0 {
            cell.secondDateSelected = endDate           
            EndDate = endDate!
        }
   
        let tempmonthTobeShown = month + indexPath.row
        var monthTobeShown = tempmonthTobeShown
        if monthTobeShown > 12 {
            var tempMonth = monthTobeShown%12
            if tempMonth == 0 {
                tempMonth = 12
            }
            monthTobeShown = tempMonth
        }
        

        year = yearStarted
        let numberOfYears = tempmonthTobeShown/12 // to get year with january
        if numberOfYears > 0 {
            for _ in 0...numberOfYears-1 {
                year = year + 1
            }
        }
        if monthTobeShown == 12 {
        cell.createCalendar(withMonth: monthTobeShown, andYear: year-1)
        } else {
            cell.createCalendar(withMonth: monthTobeShown, andYear: year)
        }


        cell.selectionStyle  = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return self.HightView.frame.size.height
    }
    
    
    func dateSelected(date: String) {
        if startDate.characters.count == 0 {
            startDate = date
        } else {
             if startDate.characters.count != 0  &&  endDate.characters.count != 0 {
                startDate = date
                endDate = ""
             }
             else {
                let localstartDate = returnDateFormatter().date(from:self.startDate)
                let localendDate = returnDateFormatter().date(from:date)
                if localendDate?.compare(localstartDate!) == .orderedAscending {
                    startDate = date
                    endDate =  returnDateFormatter().string(from: localstartDate!)
                } else {
                       endDate = date
                }
            }
        }
        tblCalendar.reloadData()
    }
    
    func returnDateFormatter() -> DateFormatter {
        
        let formatter = DateFormatter.init()
        formatter.dateFormat = "dd/MM/yyyy"
        return formatter
    }

    @IBAction func SaveButton(_ sender: Any) {
        

        startNDEnd = (" \(StartDate) to")+(" \(EndDate)")
        startNDEndArr.add(startNDEnd)
        
    }
    
    @IBAction func Close(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        newViewController.StartNdEndDate=startNDEndArr
        self.present(newViewController, animated: true, completion: nil)
    }
    
    func returnWeekDayArray() -> Array<String> {
        
        let formatter = DateFormatter.init()
        return formatter.shortWeekdaySymbols
        //  return ["apple"]
    }
}





